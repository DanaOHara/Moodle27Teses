Plugin must have more than one file.
